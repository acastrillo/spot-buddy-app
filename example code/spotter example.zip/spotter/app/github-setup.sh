
#!/bin/bash

echo "🚀 Spotter - GitHub Setup Script"
echo "================================="

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git is not installed. Please install git first."
    exit 1
fi

# Check if we're already in a git repository
if [ -d ".git" ]; then
    echo "📁 Git repository already exists."
    echo "   If you want to start fresh, run: rm -rf .git"
    read -p "   Continue with existing repository? (y/n): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    echo "📁 Initializing new git repository..."
    git init
fi

# Set up git user if not already configured
if ! git config user.name &> /dev/null; then
    read -p "📝 Enter your Git username: " git_username
    git config user.name "$git_username"
fi

if ! git config user.email &> /dev/null; then
    read -p "📧 Enter your Git email: " git_email
    git config user.email "$git_email"
fi

echo "🧹 Cleaning up sensitive files..."

# Remove sensitive files if they exist
[ -f ".env" ] && echo "   ✅ .env file will be ignored (not committed)"
[ -d "node_modules" ] && echo "   ✅ node_modules will be ignored"
[ -d ".next" ] && echo "   ✅ .next build files will be ignored"

# Add all files to git
echo "📦 Adding files to git..."
git add .

# Create initial commit
if ! git log --oneline -1 &> /dev/null; then
    echo "✨ Creating initial commit..."
    git commit -m "Initial commit: Spotter fitness tracker (UI-only version)

- Core workout tracking functionality
- User authentication and session management  
- Responsive mobile-first design
- PostgreSQL database integration
- Import/parsing features temporarily disabled for stability"
else
    echo "💾 Committing recent changes..."
    git add .
    git commit -m "Update: Simplified UI-only version

- Removed OCR and Instagram import complexity
- Focused on core workout tracking features
- Improved error handling and user experience
- Ready for GitHub deployment"
fi

echo ""
echo "🎉 Repository prepared for GitHub!"
echo ""
echo "📝 Next steps:"
echo "   1. Create a new repository on GitHub"
echo "   2. Copy the repository URL"
echo "   3. Run these commands:"
echo ""
echo "      git remote add origin <your-github-repo-url>"
echo "      git branch -M main"
echo "      git push -u origin main"
echo ""
echo "📋 Example:"
echo "   git remote add origin https://github.com/yourusername/spotter.git"
echo "   git branch -M main"
echo "   git push -u origin main"
echo ""
echo "🔗 Your repository will include:"
echo "   ✅ Complete Next.js fitness tracking app"
echo "   ✅ Clean, production-ready code"
echo "   ✅ Documentation and setup instructions"
echo "   ✅ Environment variable examples"
echo "   ✅ Proper .gitignore configuration"
echo ""
echo "⚠️  Remember to:"
echo "   • Set up your database and environment variables"
echo "   • Configure authentication secrets"
echo "   • Test the deployment on your chosen platform"
echo ""
echo "🚀 Happy coding!"
