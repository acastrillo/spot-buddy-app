
// Quick test script for the workout parser
const { parseWorkoutCaption } = require('./lib/workout-parser.js');

// Test workout examples
const testWorkouts = [
  {
    title: "Upper Body AMRAP",
    caption: `AMRAP 20 minutes
Push ups - 10 reps
Pull ups - 5 reps
Dumbbell press - 3 sets of 8
Rest 60 seconds between rounds`
  },
  {
    title: "Leg Day",
    caption: `Leg Workout
Squats 4x10
Deadlifts 3 sets of 5
Bulgarian split squats 3x8 each leg
Calf raises 2x15
Rest 90 sec between exercises`
  },
  {
    title: "Cardio HIIT",
    caption: `HIIT Workout - 15 min
Burpees - 30 seconds
Rest 10 seconds
Mountain climbers - 45 sec
Rest 15 sec
Repeat 4 rounds`
  }
];

console.log('Testing workout parser...\n');

testWorkouts.forEach((workout, index) => {
  console.log(`=== Test ${index + 1}: ${workout.title} ===`);
  console.log(`Caption: "${workout.caption}"`);
  
  try {
    const parsed = parseWorkoutCaption(workout.caption, workout.title);
    console.log('✓ Parsed successfully!');
    console.log(`Steps: ${parsed.steps.length}`);
    console.log(`Equipment: ${parsed.meta.equipment.join(', ') || 'None'}`);
    console.log(`Body Parts: ${parsed.meta.bodyParts.join(', ') || 'None'}`);
    console.log(`Workout Types: ${parsed.meta.workoutTypes.join(', ') || 'None'}`);
    console.log(`Estimated Time: ${parsed.totalTimeEstimateSec ? Math.round(parsed.totalTimeEstimateSec/60) + ' min' : 'Unknown'}`);
    console.log('');
  } catch (error) {
    console.log(`✗ Failed: ${error.message}`);
    console.log('');
  }
});
