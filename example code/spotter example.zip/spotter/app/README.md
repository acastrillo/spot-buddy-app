
# Spotter - Fitness Workout Tracker

A modern, mobile-first fitness workout tracking application built with Next.js, PostgreSQL, and TypeScript.

## Current Status: UI-Only Version

This version of Spotter focuses on the core UI/UX and basic functionality. Advanced import and parsing features have been temporarily disabled to ensure reliability and performance.

### ✅ What's Working

**Core Features:**
- ✅ User authentication (login/register)
- ✅ Workout library with search and filtering
- ✅ Manual workout creation and editing
- ✅ Workout execution with rest timers
- ✅ Exercise tracking and progress
- ✅ Responsive mobile-first design
- ✅ Dark mode UI
- ✅ Database integration (PostgreSQL)

**UI Components:**
- ✅ Modern, high-contrast design
- ✅ Smooth animations and transitions
- ✅ Touch-friendly mobile interface
- ✅ Accessible component library

### 🚧 Temporarily Disabled Features

**Import & Parsing:**
- 🚧 Image OCR text extraction (disabled)
- 🚧 Instagram workout import (disabled)
- 🚧 Automatic workout parsing (disabled)

*These features were causing performance issues and JSON parsing errors. They can be re-enabled and improved in future versions.*

## Technology Stack

- **Frontend:** Next.js 14, React 18, TypeScript
- **Styling:** Tailwind CSS, Shadcn/UI components
- **Database:** PostgreSQL with Prisma ORM
- **Authentication:** NextAuth.js
- **Deployment:** Ready for Vercel/Netlify

## Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL database
- Yarn package manager

### Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd spotter/app

# Install dependencies
yarn install

# Set up environment variables
cp .env.example .env
# Edit .env with your database URL and auth secrets

# Set up database
yarn prisma generate
yarn prisma db push

# Run development server
yarn dev
```

Visit `http://localhost:3000` to see the application.

### Environment Variables

Create a `.env` file with:

```env
DATABASE_URL="postgresql://username:password@localhost:5432/spotter"
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secret-key"
```

## Project Structure

```
app/
├── app/                 # Next.js App Router
│   ├── api/            # API routes
│   ├── auth/           # Authentication pages
│   ├── add/            # Workout import/creation
│   ├── library/        # Workout library
│   └── workout/        # Workout execution
├── components/         # React components
│   ├── ui/            # Base UI components
│   ├── auth/          # Auth components
│   └── workout/       # Workout-specific components
├── lib/               # Utilities and configurations
├── prisma/            # Database schema
└── public/            # Static assets
```

## API Routes

**Authentication:**
- `POST /api/signup` - User registration
- `GET/POST /api/auth/[...nextauth]` - NextAuth handlers

**Workouts:**
- `GET/POST /api/workouts` - Workout CRUD operations
- `GET/PUT/DELETE /api/workouts/[id]` - Individual workout operations

**Sessions:**
- `GET/POST /api/sessions` - Workout session tracking
- `GET/PUT /api/sessions/[id]` - Individual session operations

**Import (Disabled):**
- `POST /api/extract-text` - Returns 501 (disabled)
- `POST /api/instagram-fetch` - Returns 501 (disabled)
- `POST /api/parse-workout` - Returns 501 (disabled)

## Building for Production

```bash
# Build the application
yarn build

# Start production server
yarn start
```

## Deployment

The app is ready for deployment on:
- **Vercel** (recommended)
- **Netlify**
- **Any Node.js hosting platform**

Make sure to:
1. Set up your PostgreSQL database
2. Configure environment variables
3. Run database migrations: `yarn prisma db push`

## Future Enhancements

**Planned Features:**
- 🔄 Improved OCR with better error handling
- 🔄 Instagram API integration with proper rate limiting
- 🔄 Smart workout parsing with LLM assistance
- 🔄 Workout recommendations
- 🔄 Social features and sharing
- 🔄 Advanced analytics and progress tracking

## Contributing

1. Focus on UI/UX improvements
2. Add new manual workout features
3. Improve database queries and performance
4. Enhance mobile responsiveness
5. Add tests and documentation

## License

Private project - not for public distribution.

---

**Note:** This is a cleaned-up version focusing on core functionality. Advanced import features have been temporarily disabled to ensure reliability. The app provides a solid foundation for manual workout tracking with room for future enhancements.
