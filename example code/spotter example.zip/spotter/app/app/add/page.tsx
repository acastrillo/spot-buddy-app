
"use client"

import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Header } from "@/components/layout/header"
import { MobileNav } from "@/components/layout/mobile-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { 
  Download,
  FileText,
  Loader2,
  AlertTriangle,
  CheckCircle,
  Instagram,
  ExternalLink,
  Image as ImageIcon,
  Camera
} from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { FileUpload } from "@/components/ui/file-upload"
import { ManualEditor } from "@/components/workout/manual-editor"

interface ImportFormData {
  title: string
  sourceUrl: string
  caption: string
}

export default function AddWorkoutPage() {
  const { data: session, status } = useSession() || {}
  const router = useRouter()
  
  const [formData, setFormData] = useState<ImportFormData>({
    title: '',
    sourceUrl: '',
    caption: ''
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("url")
  const [ocrConfidence, setOcrConfidence] = useState<number | null>(null)
  const [showManualEditor, setShowManualEditor] = useState(false)
  const [editorSource, setEditorSource] = useState<'manual' | 'instagram' | 'image'>('manual')

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/auth/login")
    }
  }, [status, router])

  if (status === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-border border-t-primary"></div>
      </div>
    )
  }

  if (!session) {
    return null
  }

  const handleInputChange = (field: keyof ImportFormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
    
    // Auto-generate title from URL if title is empty
    if (field === 'sourceUrl' && !formData.title && value) {
      try {
        const url = new URL(value)
        const hostname = url.hostname.toLowerCase()
        if (hostname.includes('instagram.com')) {
          setFormData(prev => ({
            ...prev,
            title: `Instagram Workout - ${new Date().toLocaleDateString()}`
          }))
        } else if (hostname.includes('tiktok.com')) {
          setFormData(prev => ({
            ...prev,
            title: `TikTok Workout - ${new Date().toLocaleDateString()}`
          }))
        } else if (value.includes('http')) {
          setFormData(prev => ({
            ...prev,
            title: `Social Workout - ${new Date().toLocaleDateString()}`
          }))
        }
      } catch (e) {
        // Invalid URL, ignore
      }
    }
    
    setError(null)
    setSuccessMessage(null)
  }

  const fetchInstagramContent = async (url: string) => {
    setIsLoading(true)
    setError(null)
    
    try {
      const response = await fetch('/api/instagram-fetch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ postUrl: url }),
      })

      const result = await response.json()

      // Handle disabled Instagram functionality
      if (response.status === 501) {
        setError('Instagram import is currently disabled. Please copy and paste the workout content manually.')
        toast({
          title: "Feature Disabled",
          description: "Instagram import is temporarily unavailable. Please copy the workout text and paste it below.",
          variant: "default",
        })
        return
      }

      if (!response.ok) {
        throw new Error(result.error || 'Failed to fetch Instagram content')
      }

      // This shouldn't happen with the simplified API, but handle it gracefully
      setError('Instagram import is currently unavailable. Please use manual entry.')
      toast({
        title: "Service Unavailable",
        description: "Please copy the workout text from Instagram and paste it manually.",
        variant: "default",
      })
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch Instagram content'
      setError(errorMessage)
      toast({
        title: "Instagram Import Unavailable",
        description: "Please copy the workout text manually and paste it below.",
        variant: "default",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const parseWorkout = async () => {
    if (!formData.title.trim() || !formData.caption.trim()) {
      setError('Please provide both a title and workout caption')
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch('/api/parse-workout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      const result = await response.json()

      // Handle disabled parsing functionality
      if (response.status === 501) {
        setError('Workout parsing is currently disabled. Please create workouts manually using the workout builder.')
        toast({
          title: "Feature Disabled",
          description: "Automatic workout parsing is temporarily unavailable. Please use manual workout creation.",
          variant: "default",
        })
        // Could redirect to manual creation page here
        return
      }

      if (!response.ok) {
        throw new Error(result.error || 'Failed to parse workout')
      }

      // This shouldn't happen with the simplified API, but handle it gracefully
      setError('Workout parsing is currently unavailable. Please use manual workout creation.')
      toast({
        title: "Service Unavailable",
        description: "Please create workouts manually for now.",
        variant: "default",
      })
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to parse workout'
      setError(errorMessage)
      toast({
        title: "Parsing Unavailable",
        description: "Please create workouts manually using the workout builder.",
        variant: "default",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleTextExtracted = (extractedText: string, confidence: number) => {
    setFormData(prev => ({
      ...prev,
      caption: extractedText,
      title: prev.title || `Image Workout - ${new Date().toLocaleDateString()}`
    }))
    setOcrConfidence(confidence)
    
    // Show manual editor for editing OCR results
    setShowManualEditor(true)
    setEditorSource('image')
    
    const successMsg = `Text extracted successfully! Confidence: ${confidence.toFixed(1)}%. Review and edit the text below before parsing.`
    setSuccessMessage(successMsg)
    setError(null)
    
    toast({
      title: "Success",
      description: `Text extracted from image with ${confidence.toFixed(1)}% confidence`,
    })
  }

  const handleImageError = (errorMessage: string) => {
    setError(errorMessage)
    setOcrConfidence(null)
    toast({
      title: "Error",
      description: errorMessage,
      variant: "destructive",
    })
  }

  const handleSavePartial = (workoutId: string) => {
    // Could redirect to library or show success message
    console.log('Partial workout saved with ID:', workoutId)
  }

  const handleManualParse = async (title: string, caption: string, sourceUrl?: string) => {
    // Update form data and trigger parse
    setFormData(prev => ({
      ...prev,
      title,
      caption,
      sourceUrl: sourceUrl || prev.sourceUrl
    }))
    
    // Trigger parse
    if (!title.trim() || !caption.trim()) {
      setError('Please provide both a title and workout content')
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch('/api/parse-workout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ title, caption, sourceUrl }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || 'Failed to parse workout')
      }

      // Redirect to parsed review page with workout data
      const searchParams = new URLSearchParams({
        data: JSON.stringify(result)
      })
      router.push(`/add/review?${searchParams.toString()}`)
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to parse workout'
      setError(errorMessage)
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // URL fetching functionality will be implemented with new APIs

  return (
    <>
      <Header />
      <main className="min-h-screen pb-20 md:pb-8">
        <div className="container max-w-screen-xl mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto">
            {/* Header */}
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-text-primary mb-2">
                Import Workout
              </h1>
              <p className="text-text-secondary">
                Import from social media, upload images, or enter text manually
              </p>
            </div>

            {/* Import Methods */}
            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Import Workout
                </CardTitle>
                <CardDescription>
                  Choose how you'd like to import your workout
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger 
                      value="url" 
                      className="flex items-center gap-2" 
                      onClick={() => setActiveTab("url")}
                    >
                      <ExternalLink className="h-4 w-4" />
                      URL/Social
                    </TabsTrigger>
                    <TabsTrigger 
                      value="image" 
                      className="flex items-center gap-2"
                      onClick={() => setActiveTab("image")}
                    >
                      <ImageIcon className="h-4 w-4" />
                      Image
                    </TabsTrigger>
                    <TabsTrigger 
                      value="manual" 
                      className="flex items-center gap-2"
                      onClick={() => setActiveTab("manual")}
                    >
                      <FileText className="h-4 w-4" />
                      Manual
                    </TabsTrigger>
                  </TabsList>

                  <div className="mt-6">
                    <TabsContent value="url" className="space-y-6">
                      {/* Source URL Field */}
                      <div className="space-y-2">
                        <Label htmlFor="sourceUrl" className="flex items-center gap-2">
                          <ExternalLink className="h-4 w-4" />
                          Source URL
                        </Label>
                        <div className="flex gap-2">
                          <Input
                            id="sourceUrl"
                            value={formData.sourceUrl}
                            onChange={(e) => handleInputChange('sourceUrl', e.target.value)}
                            placeholder="https://www.instagram.com/p/ABC123xyz/ or https://www.tiktok.com/..."
                            className="bg-surface border-border flex-1"
                          />
                          <Button
                            onClick={() => formData.sourceUrl && fetchInstagramContent(formData.sourceUrl)}
                            disabled={!formData.sourceUrl || isLoading || !formData.sourceUrl.includes('instagram.com')}
                            variant="outline"
                            className="shrink-0"
                          >
                            {isLoading ? (
                              <div className="animate-spin rounded-full h-4 w-4 border-2 border-border border-t-primary"></div>
                            ) : (
                              <Download className="h-4 w-4" />
                            )}
                            Fetch
                          </Button>
                        </div>
                        <div className="text-xs text-text-secondary space-y-1">
                          <p>
                            <strong>Social media URL format:</strong> Paste URLs from Instagram, TikTok, or other platforms
                          </p>
                          <div className="flex items-start gap-1 mt-2 p-2 bg-green-500/10 border border-green-500/20 rounded text-green-700 dark:text-green-400">
                            <ExternalLink className="h-3 w-3 mt-0.5 shrink-0" />
                            <span>
                              <strong>Instagram import ready:</strong> Click "Fetch" after entering an Instagram URL to automatically extract the workout caption.
                            </span>
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="image" className="space-y-6">
                      <div className="space-y-2">
                        <Label>Upload Workout Image</Label>
                        <FileUpload
                          onTextExtracted={handleTextExtracted}
                          onError={handleImageError}
                          disabled={isLoading}
                        />
                        <p className="text-xs text-text-secondary">
                          Upload images containing workout text. Our OCR technology will extract the text automatically.
                        </p>
                        {ocrConfidence !== null && (
                          <div className="flex items-center gap-2 text-sm">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span className="text-green-700 dark:text-green-400">
                              Text extraction confidence: {ocrConfidence.toFixed(1)}%
                            </span>
                          </div>
                        )}
                      </div>
                    </TabsContent>

                    <TabsContent value="manual" className="space-y-6">
                      <ManualEditor
                        initialTitle={formData.title}
                        initialCaption={formData.caption}
                        initialSourceUrl={formData.sourceUrl}
                        source="manual"
                        onSavePartial={handleSavePartial}
                        onParseWorkout={handleManualParse}
                        disabled={isLoading}
                      />
                    </TabsContent>

                    {/* Common Fields - Title and Caption */}
                    <div className="space-y-6 mt-6 pt-6 border-t border-border">
                      <div className="space-y-2">
                        <Label htmlFor="title">Workout Title</Label>
                        <Input
                          id="title"
                          value={formData.title}
                          onChange={(e) => handleInputChange('title', e.target.value)}
                          placeholder="e.g., Upper Body Strength, AMRAP 20"
                          className="bg-surface border-border"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="caption">Workout Content</Label>
                        <Textarea
                          id="caption"
                          value={formData.caption}
                          onChange={(e) => handleInputChange('caption', e.target.value)}
                          placeholder="Your workout content will appear here..."
                          className="bg-surface border-border min-h-[200px] resize-none"
                          rows={10}
                        />
                        <p className="text-xs text-text-secondary">
                          {formData.caption.length}/5000 characters
                        </p>
                      </div>

                      {/* Status Messages */}
                      {error && (
                        <Alert variant="destructive">
                          <AlertTriangle className="h-4 w-4" />
                          <AlertDescription>{error}</AlertDescription>
                        </Alert>
                      )}

                      {successMessage && (
                        <Alert className="border-green-500/20 bg-green-500/10">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <AlertDescription className="text-green-700 dark:text-green-400">
                            {successMessage}
                          </AlertDescription>
                        </Alert>
                      )}

                      {/* Action Buttons */}
                      <div className="flex gap-3 pt-4">
                        <Button
                          onClick={parseWorkout}
                          disabled={isLoading || !formData.title.trim() || !formData.caption.trim()}
                          className="flex-1"
                          size="lg"
                        >
                          {isLoading ? (
                            <>
                              <Loader2 className="h-4 w-4 animate-spin mr-2" />
                              Parsing Workout...
                            </>
                          ) : (
                            <>
                              <FileText className="h-4 w-4 mr-2" />
                              Parse Workout
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </Tabs>
              </CardContent>
            </Card>

            {/* Manual Editor for Failed Imports or OCR Results */}
            {showManualEditor && (
              <div className="mb-8">
                <ManualEditor
                  initialTitle={formData.title}
                  initialCaption={formData.caption}
                  initialSourceUrl={formData.sourceUrl}
                  source={editorSource}
                  onSavePartial={handleSavePartial}
                  onParseWorkout={handleManualParse}
                  disabled={isLoading}
                />
              </div>
            )}

            {/* Info Card */}
            <Card className="bg-surface/50">
              <CardContent className="p-6">
                <h3 className="font-semibold text-text-primary mb-4 flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-primary" />
                  What We Can Parse
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <h4 className="font-medium text-text-primary mb-2">Exercise Formats</h4>
                    <ul className="text-text-secondary space-y-1">
                      <li>• Sets × Reps (3x10, 4 sets of 8)</li>
                      <li>• Time-based (30 sec, 1:30)</li>
                      <li>• Distances (400m, 1 mile)</li>
                      <li>• Rest periods (Rest 60s)</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-text-primary mb-2">Workout Types</h4>
                    <ul className="text-text-secondary space-y-1">
                      <li>• AMRAP, EMOM, Tabata</li>
                      <li>• For Time, Ladders</li>
                      <li>• Supersets, Circuits</li>
                      <li>• Equipment detection</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-text-primary mb-2">Import Sources</h4>
                    <ul className="text-text-secondary space-y-1">
                      <li>• Instagram posts & captions</li>
                      <li>• Image text (OCR)</li>
                      <li>• Manual text entry</li>
                      <li>• Social media URLs</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <MobileNav />
    </>
  )
}
