
import { NextRequest, NextResponse } from 'next/server'

// Simplified API - Instagram functionality disabled for now
export async function POST(request: NextRequest) {
  try {
    const { postUrl } = await request.json()
    
    if (!postUrl) {
      return NextResponse.json({ 
        error: 'Instagram post URL is required' 
      }, { status: 400 })
    }

    console.log('Instagram fetch requested for:', postUrl)

    // For now, just return a message that Instagram fetch is disabled
    return NextResponse.json({
      error: 'Instagram import is temporarily disabled',
      details: 'Instagram fetching functionality has been removed to focus on core app features',
      postUrl: postUrl,
      suggestion: 'Please use manual entry for now'
    }, { status: 501 }) // Not Implemented

  } catch (error) {
    console.error('Instagram fetch error:', error)
    return NextResponse.json({ 
      error: 'Failed to process request',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
