
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth-options"
import { prisma } from "@/lib/db"

export async function GET(
  request: NextRequest,
  { params }: { params: { workoutId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { workoutId } = params

    if (!workoutId) {
      return NextResponse.json({ error: 'Workout ID is required' }, { status: 400 })
    }

    // Fetch workout with all related data
    const workout = await prisma.workout.findFirst({
      where: {
        id: workoutId,
        userId: session.user.id, // Ensure user can only access their own workouts
      },
      include: {
        steps: {
          orderBy: {
            order: 'asc'
          }
        },
        sessions: {
          select: {
            id: true,
            endedAt: true,
            startedAt: true
          },
          orderBy: {
            startedAt: 'desc'
          }
        }
      }
    })

    if (!workout) {
      return NextResponse.json({ error: 'Workout not found' }, { status: 404 })
    }

    // Add session count
    const workoutWithSessionCount = {
      ...workout,
      sessionCount: workout.sessions.length
    }

    return NextResponse.json(workoutWithSessionCount)

  } catch (error) {
    console.error('Get workout error:', error)
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { workoutId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { workoutId } = params
    const updateData = await request.json()

    if (!workoutId) {
      return NextResponse.json({ error: 'Workout ID is required' }, { status: 400 })
    }

    // Verify workout belongs to user
    const existingWorkout = await prisma.workout.findFirst({
      where: {
        id: workoutId,
        userId: session.user.id
      }
    })

    if (!existingWorkout) {
      return NextResponse.json({ error: 'Workout not found' }, { status: 404 })
    }

    // Update workout in a transaction to handle steps
    const updatedWorkout = await prisma.$transaction(async (tx) => {
      // Update the workout metadata
      const workout = await tx.workout.update({
        where: { id: workoutId },
        data: {
          title: updateData.title || existingWorkout.title,
          bodyParts: updateData.bodyParts || existingWorkout.bodyParts,
          equipment: updateData.equipment || existingWorkout.equipment,
          workoutTypes: updateData.workoutTypes || existingWorkout.workoutTypes,
          tags: updateData.tags || existingWorkout.tags,
          totalTimeEstimateSec: updateData.totalTimeEstimateSec || existingWorkout.totalTimeEstimateSec,
          updatedAt: new Date()
        }
      })

      // If steps are provided, update them
      if (updateData.steps) {
        // Delete existing steps
        await tx.workoutStep.deleteMany({
          where: { workoutId: workoutId }
        })

        // Create new steps
        for (const step of updateData.steps) {
          await tx.workoutStep.create({
            data: {
              workoutId: workoutId,
              order: step.order,
              type: step.type || 'exercise',
              raw: step.raw || step.exercise || '',
              exercise: step.exercise,
              sets: step.sets,
              repsJson: step.repsJson,
              duration: step.duration,
              weight: step.weight,
              distance: step.distance,
              timesThrough: step.timesThrough,
              workoutTypeHint: step.workoutTypeHint,
            }
          })
        }
      }

      // Return updated workout with steps
      return await tx.workout.findUnique({
        where: { id: workoutId },
        include: {
          steps: {
            orderBy: {
              order: 'asc'
            }
          },
          sessions: {
            select: {
              id: true,
              endedAt: true,
              startedAt: true
            },
            orderBy: {
              startedAt: 'desc'
            }
          }
        }
      })
    })

    // Add session count
    const workoutWithSessionCount = {
      ...updatedWorkout,
      sessionCount: updatedWorkout?.sessions.length || 0
    }

    return NextResponse.json(workoutWithSessionCount)

  } catch (error) {
    console.error('Update workout error:', error)
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { workoutId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { workoutId } = params

    if (!workoutId) {
      return NextResponse.json({ error: 'Workout ID is required' }, { status: 400 })
    }

    // Verify workout belongs to user
    const existingWorkout = await prisma.workout.findFirst({
      where: {
        id: workoutId,
        userId: session.user.id
      }
    })

    if (!existingWorkout) {
      return NextResponse.json({ error: 'Workout not found' }, { status: 404 })
    }

    // Delete workout (this will cascade delete steps and sessions)
    await prisma.workout.delete({
      where: { id: workoutId }
    })

    return NextResponse.json({ success: true, message: 'Workout deleted' })

  } catch (error) {
    console.error('Delete workout error:', error)
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 })
  }
}
