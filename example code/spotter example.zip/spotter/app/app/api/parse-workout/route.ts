
import { NextRequest, NextResponse } from 'next/server'

interface ParseWorkoutRequest {
  title: string
  sourceUrl?: string
  caption: string
}

// Simplified API - workout parsing functionality disabled for now
export async function POST(request: NextRequest) {
  console.log('🏋️ Parse workout API called (functionality disabled)')
  
  try {
    const contentType = request.headers.get('content-type')

    if (!contentType?.includes('application/json')) {
      return NextResponse.json({ 
        error: 'Invalid request format. Expected JSON.' 
      }, { status: 400 })
    }

    let requestData: ParseWorkoutRequest
    
    try {
      requestData = await request.json()
    } catch (jsonError) {
      return NextResponse.json({ 
        error: 'Invalid JSON in request body',
        details: jsonError instanceof Error ? jsonError.message : 'JSON parse error'
      }, { status: 400 })
    }

    const { title, sourceUrl, caption } = requestData

    console.log(`📝 Parse request: title="${title}" (${caption?.length || 0} chars)`)

    if (!title?.trim() || !caption?.trim()) {
      return NextResponse.json({ 
        error: 'Title and caption are required and cannot be empty' 
      }, { status: 400 })
    }

    // For now, just return a message that parsing is disabled
    return NextResponse.json({
      error: 'Workout parsing is temporarily disabled',
      details: 'Workout parsing functionality has been removed to focus on core app features',
      received_title: title,
      received_caption_length: caption.length,
      suggestion: 'Please use manual workout creation for now'
    }, { status: 501 }) // Not Implemented

  } catch (error) {
    console.error('❌ Parse workout error:', error)
    return NextResponse.json({ 
      error: 'Failed to process request',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
