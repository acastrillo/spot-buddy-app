
"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { useRouter, useParams } from "next/navigation"
import { Header } from "@/components/layout/header"
import { MobileNav } from "@/components/layout/mobile-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import { useToast } from "@/hooks/use-toast"
import { 
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Clock,
  Target,
  SkipForward,
  Pause,
  Play,
  Flag,
  RotateCcw
} from "lucide-react"

interface WorkoutStep {
  id: string
  order: number
  type: string
  raw: string
  exercise: string | null
  sets: number | null
  repsJson: string | null
  duration: number | null
  weight: number | null
  distance: number | null
  timesThrough: number | null
  workoutTypeHint: string | null
}

interface Workout {
  id: string
  title: string
  totalTimeEstimateSec: number | null
  steps: WorkoutStep[]
}

interface WorkoutSession {
  id: string
  workoutId: string
  userId: string
  startedAt: string
  endedAt: string | null
  elapsedSec: number | null
  rpe: number | null
  notes: string | null
  workout: Workout
}

interface StepProgress {
  stepId: string
  completed: boolean
  setsCompleted: number
  totalSets: number
  notes?: string
}

export default function WorkoutRunnerPage() {
  const { data: session, status } = useSession() || {}
  const router = useRouter()
  const params = useParams()
  const workoutId = params?.workoutId as string
  const { toast } = useToast()

  const [workoutSession, setWorkoutSession] = useState<WorkoutSession | null>(null)
  const [currentStepIndex, setCurrentStepIndex] = useState(0)
  const [stepProgress, setStepProgress] = useState<Record<string, StepProgress>>({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [sessionStartTime, setSessionStartTime] = useState<Date | null>(null)
  const [elapsedSeconds, setElapsedSeconds] = useState(0)

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/auth/login")
      return
    }

    if (status === "authenticated" && workoutId) {
      startWorkoutSession()
    }
  }, [status, workoutId, router])

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null
    
    if (sessionStartTime && !workoutSession?.endedAt) {
      interval = setInterval(() => {
        const now = new Date()
        const elapsed = Math.floor((now.getTime() - sessionStartTime.getTime()) / 1000)
        setElapsedSeconds(elapsed)
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [sessionStartTime, workoutSession?.endedAt])

  const startWorkoutSession = async () => {
    try {
      setLoading(true)
      
      // Start new session
      const sessionResponse = await fetch('/api/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workoutId })
      })

      if (!sessionResponse.ok) {
        throw new Error('Failed to start workout session')
      }

      const sessionData = await sessionResponse.json()
      
      // Fetch session details with workout
      const detailResponse = await fetch(`/api/sessions/${sessionData.session.id}`)
      
      if (!detailResponse.ok) {
        throw new Error('Failed to fetch session details')
      }

      const fullSession = await detailResponse.json()
      setWorkoutSession(fullSession)
      setSessionStartTime(new Date(fullSession.startedAt))
      
      // Initialize step progress
      const initialProgress: Record<string, StepProgress> = {}
      fullSession.workout.steps.forEach((step: WorkoutStep) => {
        if (step.type === 'exercise') {
          initialProgress[step.id] = {
            stepId: step.id,
            completed: false,
            setsCompleted: 0,
            totalSets: step.sets || 1
          }
        }
      })
      setStepProgress(initialProgress)
      
      // Load saved progress from localStorage
      const savedProgress = localStorage.getItem(`workout-session-${fullSession.id}`)
      if (savedProgress) {
        const parsed = JSON.parse(savedProgress)
        setStepProgress(parsed.stepProgress || initialProgress)
        setCurrentStepIndex(parsed.currentStepIndex || 0)
      }

      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start workout')
      toast({
        title: "Error",
        description: "Failed to start workout session",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const saveProgressToLocal = () => {
    if (workoutSession) {
      const progressData = {
        sessionId: workoutSession.id,
        currentStepIndex,
        stepProgress,
        timestamp: new Date().toISOString()
      }
      localStorage.setItem(`workout-session-${workoutSession.id}`, JSON.stringify(progressData))
    }
  }

  const markSetComplete = (stepId: string) => {
    setStepProgress(prev => {
      const current = prev[stepId]
      if (!current) return prev
      
      const newSetsCompleted = Math.min(current.setsCompleted + 1, current.totalSets)
      const updated = {
        ...prev,
        [stepId]: {
          ...current,
          setsCompleted: newSetsCompleted,
          completed: newSetsCompleted >= current.totalSets
        }
      }
      
      // Save to localStorage immediately
      setTimeout(() => saveProgressToLocal(), 100)
      
      return updated
    })

    toast({
      title: "Set Complete!",
      description: "Great work! Keep going.",
    })
  }

  const resetStep = (stepId: string) => {
    setStepProgress(prev => ({
      ...prev,
      [stepId]: {
        ...prev[stepId],
        setsCompleted: 0,
        completed: false
      }
    }))

    setTimeout(() => saveProgressToLocal(), 100)
  }

  const nextStep = () => {
    if (workoutSession && currentStepIndex < workoutSession.workout.steps.length - 1) {
      setCurrentStepIndex(prev => prev + 1)
      setTimeout(() => saveProgressToLocal(), 100)
    }
  }

  const prevStep = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1)
      setTimeout(() => saveProgressToLocal(), 100)
    }
  }

  const completeWorkout = async () => {
    if (!workoutSession) return

    try {
      const endTime = new Date()
      
      await fetch(`/api/sessions/${workoutSession.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          endedAt: endTime.toISOString(),
          elapsedSec: elapsedSeconds,
          rpe: 7, // Default RPE, could be user input later
          notes: 'Completed via workout runner'
        })
      })

      // Clear localStorage
      localStorage.removeItem(`workout-session-${workoutSession.id}`)

      toast({
        title: "Workout Complete! 🎉",
        description: `Great job! You completed "${workoutSession.workout.title}" in ${formatTime(elapsedSeconds)}.`,
      })

      // Navigate back to library after a short delay
      setTimeout(() => {
        router.push('/library')
      }, 2000)

    } catch (err) {
      console.error('Error completing workout:', err)
      toast({
        title: "Error",
        description: "Failed to save workout completion",
        variant: "destructive",
      })
    }
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const formatReps = (repsJson: string | null, sets: number | null) => {
    if (!repsJson && !sets) return ''
    if (sets && repsJson) return `${sets} × ${repsJson}`
    if (sets) return `${sets} sets`
    if (repsJson) return repsJson
    return ''
  }

  const calculateOverallProgress = () => {
    if (!workoutSession) return 0
    
    const exerciseSteps = workoutSession.workout.steps.filter(step => step.type === 'exercise')
    if (exerciseSteps.length === 0) return 0

    const totalSets = exerciseSteps.reduce((sum, step) => sum + (step.sets || 1), 0)
    const completedSets = exerciseSteps.reduce((sum, step) => {
      const progress = stepProgress[step.id]
      return sum + (progress?.setsCompleted || 0)
    }, 0)

    return totalSets > 0 ? Math.round((completedSets / totalSets) * 100) : 0
  }

  if (status === "loading" || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner />
      </div>
    )
  }

  if (!session) {
    return null
  }

  if (error) {
    return (
      <>
        <Header />
        <main className="min-h-screen pb-20 md:pb-8">
          <div className="container max-w-screen-lg mx-auto px-4 py-8">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-text-primary mb-2">Unable to Start Workout</h1>
              <p className="text-text-secondary mb-4">{error}</p>
              <Button onClick={() => router.push(`/library/${workoutId}`)} variant="outline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Workout Details
              </Button>
            </div>
          </div>
        </main>
        <MobileNav />
      </>
    )
  }

  if (!workoutSession) {
    return (
      <>
        <Header />
        <main className="min-h-screen pb-20 md:pb-8">
          <div className="container max-w-screen-lg mx-auto px-4 py-8">
            <LoadingSpinner />
          </div>
        </main>
        <MobileNav />
      </>
    )
  }

  const currentStep = workoutSession.workout.steps[currentStepIndex]
  const isLastStep = currentStepIndex === workoutSession.workout.steps.length - 1
  const currentStepProgress = stepProgress[currentStep.id]
  const overallProgress = calculateOverallProgress()

  return (
    <>
      <Header />
      <main className="min-h-screen pb-20 md:pb-8 bg-background">
        <div className="container max-w-screen-lg mx-auto px-4 py-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <Button 
              onClick={() => router.push(`/library/${workoutId}`)} 
              variant="ghost"
              size="sm"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Exit
            </Button>
            
            <div className="text-center">
              <div className="flex items-center gap-2 text-sm text-text-secondary">
                <Clock className="h-4 w-4" />
                {formatTime(elapsedSeconds)}
              </div>
            </div>

            <Badge variant="secondary" className="text-xs">
              {currentStepIndex + 1} of {workoutSession.workout.steps.length}
            </Badge>
          </div>

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex items-center justify-between text-sm text-text-secondary mb-2">
              <span>Overall Progress</span>
              <span>{overallProgress}% Complete</span>
            </div>
            <Progress value={overallProgress} className="h-2" />
          </div>

          {/* Current Step */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                    {currentStep.order + 1}
                  </div>
                  <div>
                    <CardTitle className="text-lg">
                      {currentStep.exercise || 'Exercise'}
                    </CardTitle>
                    <CardDescription>
                      {currentStep.type === 'exercise' && formatReps(currentStep.repsJson, currentStep.sets)}
                      {currentStep.duration && ` • ${currentStep.duration}s duration`}
                      {currentStep.weight && ` • ${currentStep.weight} lbs`}
                    </CardDescription>
                  </div>
                </div>
                
                <Badge variant={currentStep.type === 'exercise' ? 'default' : 'secondary'}>
                  {currentStep.type}
                </Badge>
              </div>
            </CardHeader>

            {currentStep.type === 'exercise' && currentStepProgress && (
              <CardContent>
                <div className="space-y-4">
                  {/* Set Progress */}
                  <div>
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span>Sets Completed</span>
                      <span>
                        {currentStepProgress.setsCompleted} / {currentStepProgress.totalSets}
                      </span>
                    </div>
                    <Progress 
                      value={(currentStepProgress.setsCompleted / currentStepProgress.totalSets) * 100} 
                      className="h-2"
                    />
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-3">
                    {currentStepProgress.setsCompleted < currentStepProgress.totalSets ? (
                      <Button 
                        onClick={() => markSetComplete(currentStep.id)}
                        className="flex-1"
                        size="lg"
                      >
                        <CheckCircle2 className="h-5 w-5 mr-2" />
                        Complete Set {currentStepProgress.setsCompleted + 1}
                      </Button>
                    ) : (
                      <div className="flex gap-2 flex-1">
                        <Button 
                          onClick={() => resetStep(currentStep.id)}
                          variant="outline"
                          className="flex-1"
                        >
                          <RotateCcw className="h-4 w-4 mr-2" />
                          Reset
                        </Button>
                        {!isLastStep ? (
                          <Button 
                            onClick={nextStep}
                            className="flex-1"
                          >
                            Next Step
                            <ArrowRight className="h-4 w-4 ml-2" />
                          </Button>
                        ) : (
                          <Button 
                            onClick={completeWorkout}
                            className="flex-1"
                          >
                            <Flag className="h-4 w-4 mr-2" />
                            Finish Workout
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            )}

            {currentStep.type !== 'exercise' && (
              <CardContent>
                <div className="text-center space-y-4">
                  <p className="text-text-secondary">
                    {currentStep.raw}
                  </p>
                  <Button 
                    onClick={nextStep}
                    disabled={isLastStep}
                    className="w-full"
                  >
                    {isLastStep ? 'Last Step' : 'Continue'}
                    {!isLastStep && <ArrowRight className="h-4 w-4 ml-2" />}
                  </Button>
                </div>
              </CardContent>
            )}
          </Card>

          {/* Navigation */}
          <div className="flex justify-between gap-4">
            <Button 
              onClick={prevStep}
              disabled={currentStepIndex === 0}
              variant="outline"
              size="lg"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>

            <Button 
              onClick={nextStep}
              disabled={isLastStep}
              variant="outline" 
              size="lg"
            >
              <SkipForward className="h-4 w-4 mr-2" />
              Skip Step
            </Button>
          </div>

          {/* Workout Overview */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-base">Workout: {workoutSession.workout.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-center">
                  <div className="font-semibold text-text-primary">{workoutSession.workout.steps.length}</div>
                  <div className="text-text-secondary">Total Steps</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold text-text-primary">
                    {workoutSession.workout.steps.filter(s => s.type === 'exercise').length}
                  </div>
                  <div className="text-text-secondary">Exercises</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <MobileNav />
    </>
  )
}
