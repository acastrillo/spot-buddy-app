
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('Starting database seeding...')

  try {
    // Create test user
    const hashedPassword = await bcrypt.hash('johndoe123', 12)
    
    const testUser = await prisma.user.upsert({
      where: { email: 'john@doe.com' },
      update: {},
      create: {
        email: 'john@doe.com',
        password: hashedPassword,
        firstName: 'John',
        lastName: 'Doe',
      },
    })

    console.log('Created test user:', testUser.email)

    // Seed dictionaries
    const equipmentTerms = [
      { term: 'Barbell', normalized: 'barbell' },
      { term: 'Dumbbell', normalized: 'dumbbell' },
      { term: 'Kettlebell', normalized: 'kettlebell' },
      { term: 'Pull-up bar', normalized: 'pullup_bar' },
      { term: 'Cable machine', normalized: 'cable_machine' },
      { term: 'Resistance bands', normalized: 'resistance_bands' },
      { term: 'Bench', normalized: 'bench' },
      { term: 'Squat rack', normalized: 'squat_rack' },
      { term: 'Treadmill', normalized: 'treadmill' },
      { term: 'Rowing machine', normalized: 'rowing_machine' },
      { term: 'None', normalized: 'bodyweight' },
    ]

    const workoutTypes = [
      { term: 'Strength', normalized: 'strength' },
      { term: 'Cardio', normalized: 'cardio' },
      { term: 'HIIT', normalized: 'hiit' },
      { term: 'Yoga', normalized: 'yoga' },
      { term: 'Pilates', normalized: 'pilates' },
      { term: 'CrossFit', normalized: 'crossfit' },
      { term: 'Bodyweight', normalized: 'bodyweight' },
      { term: 'Powerlifting', normalized: 'powerlifting' },
      { term: 'Calisthenics', normalized: 'calisthenics' },
      { term: 'Stretching', normalized: 'stretching' },
    ]

    const bodyParts = [
      { term: 'Chest', normalized: 'chest' },
      { term: 'Back', normalized: 'back' },
      { term: 'Shoulders', normalized: 'shoulders' },
      { term: 'Arms', normalized: 'arms' },
      { term: 'Biceps', normalized: 'biceps' },
      { term: 'Triceps', normalized: 'triceps' },
      { term: 'Legs', normalized: 'legs' },
      { term: 'Quadriceps', normalized: 'quadriceps' },
      { term: 'Hamstrings', normalized: 'hamstrings' },
      { term: 'Glutes', normalized: 'glutes' },
      { term: 'Calves', normalized: 'calves' },
      { term: 'Core', normalized: 'core' },
      { term: 'Abs', normalized: 'abs' },
      { term: 'Full Body', normalized: 'full_body' },
    ]

    // Insert equipment dictionary entries
    for (const equipment of equipmentTerms) {
      await prisma.dictionary.upsert({
        where: {
          kind_normalized: {
            kind: 'equipment',
            normalized: equipment.normalized,
          },
        },
        update: {},
        create: {
          kind: 'equipment',
          term: equipment.term,
          normalized: equipment.normalized,
        },
      })
    }

    console.log(`Seeded ${equipmentTerms.length} equipment terms`)

    // Insert workout type dictionary entries
    for (const type of workoutTypes) {
      await prisma.dictionary.upsert({
        where: {
          kind_normalized: {
            kind: 'type',
            normalized: type.normalized,
          },
        },
        update: {},
        create: {
          kind: 'type',
          term: type.term,
          normalized: type.normalized,
        },
      })
    }

    console.log(`Seeded ${workoutTypes.length} workout types`)

    // Insert body part dictionary entries
    for (const bodyPart of bodyParts) {
      await prisma.dictionary.upsert({
        where: {
          kind_normalized: {
            kind: 'bodypart',
            normalized: bodyPart.normalized,
          },
        },
        update: {},
        create: {
          kind: 'bodypart',
          term: bodyPart.term,
          normalized: bodyPart.normalized,
        },
      })
    }

    console.log(`Seeded ${bodyParts.length} body parts`)

    // Create a sample workout for the test user
    const sampleWorkout = await prisma.workout.create({
      data: {
        title: 'Upper Body Strength',
        caption: 'A comprehensive upper body workout focusing on chest, back, and arms',
        userId: testUser.id,
        equipment: ['barbell', 'dumbbell', 'bench'],
        workoutTypes: ['strength'],
        bodyParts: ['chest', 'back', 'arms'],
        tags: ['strength', 'upper-body', 'muscle-building'],
        totalTimeEstimateSec: 3600, // 1 hour
        detectedTitle: 'Upper Body Strength Training',
        steps: {
          create: [
            {
              order: 1,
              type: 'exercise',
              raw: 'Bench Press: 4 sets of 8-10 reps',
              exercise: 'Bench Press',
              sets: 4,
              repsJson: '[8,10]',
              workoutTypeHint: 'strength',
            },
            {
              order: 2,
              type: 'rest',
              raw: 'Rest 90 seconds',
              duration: 90,
            },
            {
              order: 3,
              type: 'exercise',
              raw: 'Bent-over Barbell Row: 4 sets of 8-10 reps',
              exercise: 'Bent-over Barbell Row',
              sets: 4,
              repsJson: '[8,10]',
              workoutTypeHint: 'strength',
            },
            {
              order: 4,
              type: 'rest',
              raw: 'Rest 90 seconds',
              duration: 90,
            },
            {
              order: 5,
              type: 'exercise',
              raw: 'Overhead Press: 3 sets of 10-12 reps',
              exercise: 'Overhead Press',
              sets: 3,
              repsJson: '[10,12]',
              workoutTypeHint: 'strength',
            },
          ],
        },
      },
    })

    console.log('Created sample workout:', sampleWorkout.title)

    console.log('Database seeding completed successfully!')

  } catch (error) {
    console.error('Error during seeding:', error)
    throw error
  }
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
