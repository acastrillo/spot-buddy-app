
#!/usr/bin/env python3
"""
Simple rate limit tracker for Instagram requests
Helps avoid making requests when we know we're likely to be blocked
"""

import json
import os
import time
from typing import Dict, Any

class RateLimitTracker:
    def __init__(self, cache_file: str = "/tmp/spotter_rate_limit_cache.json"):
        self.cache_file = cache_file
        self.data = self._load_cache()
    
    def _load_cache(self) -> Dict[str, Any]:
        """Load rate limit data from cache file"""
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r') as f:
                    return json.load(f)
        except Exception:
            pass
        
        return {
            'last_rate_limit': 0,
            'consecutive_failures': 0,
            'last_success': 0,
            'requests_today': 0,
            'last_reset': 0
        }
    
    def _save_cache(self):
        """Save rate limit data to cache file"""
        try:
            with open(self.cache_file, 'w') as f:
                json.dump(self.data, f)
        except Exception:
            pass
    
    def should_attempt_request(self) -> tuple[bool, str]:
        """
        Check if we should attempt a request based on recent history
        
        Returns:
            (should_attempt, reason)
        """
        current_time = time.time()
        
        # Reset daily counter if needed
        if current_time - self.data['last_reset'] > 86400:  # 24 hours
            self.data['requests_today'] = 0
            self.data['last_reset'] = current_time
        
        # Check if we were recently rate limited
        time_since_rate_limit = current_time - self.data['last_rate_limit']
        if time_since_rate_limit < 900:  # 15 minutes
            minutes_left = (900 - time_since_rate_limit) / 60
            return False, f"Recently rate limited. Try again in {minutes_left:.1f} minutes."
        
        # Check consecutive failures
        if self.data['consecutive_failures'] >= 3:
            time_since_last_failure = current_time - self.data['last_rate_limit']
            if time_since_last_failure < 1800:  # 30 minutes
                minutes_left = (1800 - time_since_last_failure) / 60
                return False, f"Too many recent failures. Try again in {minutes_left:.1f} minutes."
        
        # Check daily request limit (conservative)
        if self.data['requests_today'] >= 10:
            return False, "Daily request limit reached. Try again tomorrow or paste manually."
        
        return True, "OK to attempt"
    
    def record_attempt(self, success: bool, rate_limited: bool = False):
        """Record the result of a request attempt"""
        current_time = time.time()
        
        self.data['requests_today'] += 1
        
        if success:
            self.data['last_success'] = current_time
            self.data['consecutive_failures'] = 0
        else:
            self.data['consecutive_failures'] += 1
            
            if rate_limited:
                self.data['last_rate_limit'] = current_time
        
        self._save_cache()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get current rate limiting stats"""
        current_time = time.time()
        return {
            'requests_today': self.data['requests_today'],
            'consecutive_failures': self.data['consecutive_failures'],
            'minutes_since_last_rate_limit': (current_time - self.data['last_rate_limit']) / 60,
            'minutes_since_last_success': (current_time - self.data['last_success']) / 60
        }
