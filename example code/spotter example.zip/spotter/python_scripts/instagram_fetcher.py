
#!/usr/bin/env python3
"""
Instagram Caption Fetcher using Instaloader
Extracts caption and metadata from Instagram posts by shortcode
"""

import sys
import json
import instaloader
import re
import time
import random
import os
import tempfile
from typing import Dict, Optional, Any
import logging
import requests
from bs4 import BeautifulSoup
from rate_limit_tracker import RateLimitTracker

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class InstagramFetcher:
    def __init__(self):
        """Initialize Instaloader instance with optimized settings and session management"""
        
        # Initialize rate limit tracker
        self.rate_tracker = RateLimitTracker()
        
        # Create session directory
        self.session_dir = os.path.join(tempfile.gettempdir(), 'spotter_instagram_sessions')
        os.makedirs(self.session_dir, exist_ok=True)
        
        # List of realistic user agents to rotate
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1.2 Safari/605.1.15"
        ]
        
        # Rate limiting tracking
        self.last_request_time = 0
        self.request_count = 0
        self.session_start_time = time.time()
        
        self.loader = None
        self._init_loader()
    
    def _init_loader(self):
        """Initialize loader with current settings"""
        current_user_agent = random.choice(self.user_agents)
        
        self.loader = instaloader.Instaloader(
            # Optimize settings for caption fetching only
            download_videos=False,
            download_video_thumbnails=False,
            download_geotags=False,
            download_comments=False,
            save_metadata=False,
            compress_json=False,
            post_metadata_txt_pattern="",
            download_pictures=False,
            # Rate limiting settings
            max_connection_attempts=2,
            request_timeout=20.0,
            # Use rotating user agent
            user_agent=current_user_agent,
            # Session directory for persistence
            dirname_pattern=self.session_dir,
            # Additional rate limiting
            fatal_status_codes=[429, 401, 403]  # Treat these as fatal to trigger fallback
        )
        
        logger.info(f"Initialized Instaloader with user agent: {current_user_agent[:50]}...")
    
    def _smart_delay(self):
        """Implement intelligent delays to avoid rate limiting"""
        current_time = time.time()
        
        # Base delay between requests (3-8 seconds)
        base_delay = random.uniform(3.0, 8.0)
        
        # Increase delay based on request count
        if self.request_count > 5:
            base_delay += random.uniform(2.0, 5.0)
        if self.request_count > 10:
            base_delay += random.uniform(5.0, 10.0)
            
        # Ensure minimum delay since last request
        time_since_last = current_time - self.last_request_time
        if time_since_last < base_delay:
            sleep_time = base_delay - time_since_last
            logger.info(f"Smart delay: waiting {sleep_time:.2f} seconds (request #{self.request_count})")
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
        self.request_count += 1
        
        # Reset session periodically to avoid long-term tracking
        session_duration = current_time - self.session_start_time
        if session_duration > 300:  # 5 minutes
            logger.info("Refreshing session after 5 minutes")
            self._refresh_session()
    
    def _refresh_session(self):
        """Refresh the loader session with new user agent"""
        self.request_count = 0
        self.session_start_time = time.time()
        self._init_loader()
    
    def extract_shortcode_from_url(self, url: str) -> Optional[str]:
        """
        Extract Instagram post shortcode from various URL formats
        
        Examples:
        - https://www.instagram.com/p/ABC123xyz/ -> ABC123xyz
        - https://instagram.com/p/ABC123xyz/?utm_source=... -> ABC123xyz
        """
        patterns = [
            r'instagram\.com/p/([A-Za-z0-9_-]+)',
            r'instagram\.com/reel/([A-Za-z0-9_-]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        
        return None
    
    def fetch_post_data(self, shortcode: str, max_retries: int = 2) -> Dict[str, Any]:
        """
        Fetch Instagram post data by shortcode with intelligent retry logic
        
        Args:
            shortcode: Instagram post shortcode (e.g., 'ABC123xyz')
            max_retries: Maximum number of retry attempts
            
        Returns:
            Dictionary containing post data
        """
        for attempt in range(max_retries):
            try:
                logger.info(f"Fetching post data for shortcode: {shortcode} (attempt {attempt + 1}/{max_retries})")
                
                # Apply smart delay before each request
                self._smart_delay()
                
                # Refresh session on retry to get new user agent
                if attempt > 0:
                    logger.info("Refreshing session with new user agent for retry...")
                    self._refresh_session()
                    # Additional delay after session refresh
                    extra_delay = random.uniform(5.0, 12.0)
                    logger.info(f"Additional delay after session refresh: {extra_delay:.2f} seconds")
                    time.sleep(extra_delay)
                
                # Get post by shortcode
                post = instaloader.Post.from_shortcode(self.loader.context, shortcode)
                
                # Extract relevant data
                post_data = {
                    'success': True,
                    'caption': post.caption or "",
                    'hashtags': list(post.caption_hashtags) if post.caption_hashtags else [],
                    'mentions': list(post.caption_mentions) if post.caption_mentions else [],
                    'date': post.date.isoformat() if post.date else None,
                    'likes': post.likes,
                    'is_video': post.is_video,
                    'typename': post.typename,
                    'url': f"https://www.instagram.com/p/{shortcode}/",
                    'owner_username': post.owner_username,
                    'shortcode': shortcode
                }
                
                # Add location if available
                if post.location:
                    post_data['location'] = {
                        'name': post.location.name,
                        'id': post.location.id
                    }
                
                logger.info(f"Successfully fetched post data. Caption length: {len(post_data['caption'])}")
                return post_data
                
            except instaloader.QueryReturnedNotFoundException:
                logger.error(f"Post not available: {shortcode}")
                return {
                    'success': False,
                    'error': 'Post not found or is private',
                    'error_type': 'post_unavailable'
                }
            
            except instaloader.ProfileNotExistsException:
                logger.error(f"Profile not found for post: {shortcode}")
                return {
                    'success': False,
                    'error': 'Profile not found',
                    'error_type': 'profile_not_found'
                }
            
            except instaloader.LoginRequiredException:
                logger.error("Login required for this post")
                return {
                    'success': False,
                    'error': 'This post requires login to access. It may be from a private account.',
                    'error_type': 'login_required'
                }
            
            except instaloader.TooManyRequestsException as e:
                logger.warning(f"Rate limited by Instagram: {str(e)}")
                if attempt < max_retries - 1:
                    # Longer delay for rate limit recovery
                    backoff_delay = random.uniform(20.0, 45.0) * (2 ** attempt)
                    logger.warning(f"Rate limited - waiting {backoff_delay:.1f} seconds before retry...")
                    time.sleep(backoff_delay)
                    continue
                else:
                    logger.error("Rate limited by Instagram - all retries exhausted")
                    return {
                        'success': False,
                        'error': 'Instagram is currently rate limiting requests. This is common and usually temporary. Please wait 10-15 minutes before trying again, or manually paste the workout text.',
                        'error_type': 'rate_limited',
                        'suggestion': 'Try again in 10-15 minutes or paste the workout manually'
                    }
            
            except instaloader.ConnectionException as e:
                error_msg = str(e).lower()
                logger.warning(f"Connection issue: {str(e)}")
                
                # Analyze specific connection errors
                is_rate_limit_related = any(term in error_msg for term in [
                    '401', '403', '429', 'unauthorized', 'forbidden', 
                    'too many requests', 'rate limit', 'please wait'
                ])
                
                if is_rate_limit_related:
                    if attempt < max_retries - 1:
                        # Extended delay for suspected rate limiting
                        backoff_delay = random.uniform(15.0, 30.0) * (2 ** attempt)
                        logger.warning(f"Rate limit detected in connection error - waiting {backoff_delay:.1f} seconds...")
                        time.sleep(backoff_delay)
                        continue
                    else:
                        return {
                            'success': False,
                            'error': 'Instagram temporarily blocked the request due to rate limiting. This is normal behavior to prevent abuse.',
                            'error_type': 'rate_limited',
                            'suggestion': 'Wait 10-15 minutes before trying again, or paste the workout text manually'
                        }
                        
                elif any(term in error_msg for term in ['timeout', 'connection', 'network']) and attempt < max_retries - 1:
                    # Network-related issues - shorter delay
                    logger.warning(f"Network issue detected, retrying... (attempt {attempt + 1}/{max_retries})")
                    time.sleep(random.uniform(3.0, 8.0))
                    continue
                else:
                    logger.error(f"Connection error: {str(e)}")
                    return {
                        'success': False,
                        'error': 'Failed to connect to Instagram. This could be due to network issues or Instagram being temporarily unavailable.',
                        'error_type': 'connection_error',
                        'suggestion': 'Check your internet connection and try again, or paste the workout text manually'
                    }
            
            except Exception as e:
                error_str = str(e).lower()
                
                # Check if this is actually a rate limiting issue disguised as generic error
                if any(term in error_str for term in ['403', '401', '429', 'forbidden', 'unauthorized', 'rate limit']):
                    logger.warning(f"Rate limiting detected in generic error: {str(e)}")
                    if attempt < max_retries - 1:
                        backoff_delay = random.uniform(10.0, 25.0) * (2 ** attempt)
                        logger.warning(f"Waiting {backoff_delay:.1f} seconds before retry...")
                        time.sleep(backoff_delay)
                        continue
                    else:
                        return {
                            'success': False,
                            'error': 'Instagram temporarily blocked the request. This commonly happens to prevent automated access.',
                            'error_type': 'rate_limited',
                            'suggestion': 'Wait 10-15 minutes before trying again, or paste the workout text manually'
                        }
                
                if attempt < max_retries - 1:
                    logger.warning(f"Unexpected error, retrying... (attempt {attempt + 1}/{max_retries}): {str(e)}")
                    continue
                else:
                    logger.error(f"Unexpected error: {str(e)}")
                    return {
                        'success': False,
                        'error': f'Failed to fetch post: {str(e)}',
                        'error_type': 'unknown_error'
                    }
        
        # This should never be reached, but just in case
        return {
            'success': False,
            'error': 'Maximum retry attempts exceeded',
            'error_type': 'max_retries_exceeded'
        }
    
    def _fallback_http_fetch(self, shortcode: str) -> Dict[str, Any]:
        """
        Fallback method using direct HTTP requests to Instagram's web interface
        
        Args:
            shortcode: Instagram post shortcode
            
        Returns:
            Dictionary containing post data or error information
        """
        logger.info(f"Attempting HTTP fallback for shortcode: {shortcode}")
        
        try:
            # Realistic headers for web scraping
            headers = {
                'User-Agent': random.choice(self.user_agents),
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'DNT': '1',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Cache-Control': 'max-age=0'
            }
            
            # Instagram post URL
            url = f"https://www.instagram.com/p/{shortcode}/"
            
            # Add delay before request
            time.sleep(random.uniform(2.0, 5.0))
            
            session = requests.Session()
            response = session.get(url, headers=headers, timeout=15)
            
            if response.status_code != 200:
                logger.warning(f"HTTP fallback failed with status code: {response.status_code}")
                return {
                    'success': False,
                    'error': f'Failed to access Instagram post (HTTP {response.status_code})',
                    'error_type': 'http_error'
                }
            
            # Parse HTML content
            soup = BeautifulSoup(response.content, 'lxml')
            
            # Try to extract data from script tags containing JSON
            script_tags = soup.find_all('script', type='application/ld+json')
            for script in script_tags:
                try:
                    json_data = json.loads(script.string)
                    if isinstance(json_data, dict) and 'description' in json_data:
                        caption = json_data.get('description', '')
                        
                        # Extract hashtags and mentions from caption
                        hashtags = re.findall(r'#\w+', caption)
                        mentions = re.findall(r'@\w+', caption)
                        
                        logger.info(f"HTTP fallback successful. Caption length: {len(caption)}")
                        return {
                            'success': True,
                            'caption': caption,
                            'hashtags': [tag[1:] for tag in hashtags],  # Remove #
                            'mentions': [mention[1:] for mention in mentions],  # Remove @
                            'date': None,  # Not available via this method
                            'likes': -1,   # Not available via this method
                            'is_video': None,
                            'typename': 'Unknown',
                            'url': url,
                            'owner_username': 'unknown',
                            'shortcode': shortcode,
                            'method': 'http_fallback'
                        }
                except json.JSONDecodeError:
                    continue
            
            # Try alternative extraction from meta tags
            description_meta = soup.find('meta', property='og:description')
            if description_meta and description_meta.get('content'):
                caption = description_meta.get('content', '')
                hashtags = re.findall(r'#\w+', caption)
                mentions = re.findall(r'@\w+', caption)
                
                logger.info(f"HTTP fallback successful via meta tags. Caption length: {len(caption)}")
                return {
                    'success': True,
                    'caption': caption,
                    'hashtags': [tag[1:] for tag in hashtags],
                    'mentions': [mention[1:] for mention in mentions],
                    'date': None,
                    'likes': -1,
                    'is_video': None,
                    'typename': 'Unknown',
                    'url': url,
                    'owner_username': 'unknown',
                    'shortcode': shortcode,
                    'method': 'http_fallback'
                }
            
            logger.warning("HTTP fallback could not extract caption from page")
            return {
                'success': False,
                'error': 'Could not extract caption from Instagram page using HTTP method',
                'error_type': 'extraction_failed'
            }
            
        except requests.RequestException as e:
            logger.error(f"HTTP fallback request failed: {str(e)}")
            return {
                'success': False,
                'error': f'HTTP request failed: {str(e)}',
                'error_type': 'request_failed'
            }
        except Exception as e:
            logger.error(f"HTTP fallback unexpected error: {str(e)}")
            return {
                'success': False,
                'error': f'HTTP fallback failed: {str(e)}',
                'error_type': 'fallback_error'
            }
    
    def process_url(self, url: str) -> Dict[str, Any]:
        """
        Process Instagram URL and return post data with fallback support and smart rate limiting
        
        Args:
            url: Instagram post URL
            
        Returns:
            Dictionary containing post data or error information
        """
        # Extract shortcode from URL
        shortcode = self.extract_shortcode_from_url(url)
        
        if not shortcode:
            return {
                'success': False,
                'error': 'Invalid Instagram URL format. Expected format: https://www.instagram.com/p/ABC123xyz/',
                'error_type': 'invalid_url'
            }
        
        # Check with rate limit tracker before attempting
        should_attempt, reason = self.rate_tracker.should_attempt_request()
        if not should_attempt:
            logger.warning(f"Rate limit check failed: {reason}")
            stats = self.rate_tracker.get_stats()
            return {
                'success': False,
                'error': f"Rate limit protection active: {reason}",
                'error_type': 'rate_limited',
                'suggestion': 'Wait and try again later, or paste the workout text manually',
                'stats': stats
            }
        
        # Try primary method (Instaloader)
        logger.info("Rate limit check passed. Attempting primary fetch method (Instaloader)...")
        result = self.fetch_post_data(shortcode)
        
        # Record the result with rate tracker
        is_rate_limited = result.get('error_type') == 'rate_limited'
        self.rate_tracker.record_attempt(result['success'], is_rate_limited)
        
        # If primary method failed due to rate limiting, try HTTP fallback
        if not result['success'] and result.get('error_type') in ['rate_limited', 'connection_error', 'max_retries_exceeded']:
            logger.info("Primary method failed due to rate limiting/connection issues. Trying HTTP fallback...")
            fallback_result = self._fallback_http_fetch(shortcode)
            
            if fallback_result['success']:
                logger.info("HTTP fallback succeeded!")
                # Record successful fallback
                self.rate_tracker.record_attempt(True, False)
                return fallback_result
            else:
                logger.warning("HTTP fallback also failed. Returning original error with fallback info.")
                # Return original error but mention we tried fallback
                result['fallback_attempted'] = True
                result['fallback_error'] = fallback_result.get('error', 'Unknown fallback error')
                
                # Improve error message to mention both attempts
                original_error = result.get('error', 'Unknown error')
                result['error'] = f"{original_error} We also tried an alternative method, but it didn't work either."
        
        # Add current stats to result for debugging
        result['rate_limit_stats'] = self.rate_tracker.get_stats()
        
        return result


def main():
    """Main function for command-line usage"""
    if len(sys.argv) != 2:
        print(json.dumps({
            'success': False,
            'error': 'Usage: python instagram_fetcher.py <instagram_url>',
            'error_type': 'invalid_usage'
        }))
        sys.exit(1)
    
    url = sys.argv[1]
    
    try:
        fetcher = InstagramFetcher()
        result = fetcher.process_url(url)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
        # Exit with appropriate code
        sys.exit(0 if result['success'] else 1)
        
    except Exception as e:
        print(json.dumps({
            'success': False,
            'error': f'Script error: {str(e)}',
            'error_type': 'script_error'
        }))
        sys.exit(1)


if __name__ == '__main__':
    main()
